import os
import argparse
import numpy as np
from scipy import ndimage
import sys
import time

def parse_arguments(argv):
    parser = argparse.ArgumentParser()

    parser.add_argument('--dir', type=str)
    parser.add_argument('--out', type=str)
    parser.add_argument('--n', type=int)
    parser.add_argument('--seed', type=int)

    return parser.parse_args(argv)

def read_emb(path, feature_dim):
    f = open(path, 'r')
    lines = f.readlines()
    emb_str = []
    for i in range(len(lines)):
        tmp = []
        tmp += lines[i].strip().split(" ")
        emb_str.append(tmp)
    f.close()

    emb_X = []
    emb_Y = []
    for i in range(len(emb_str)):
        tmp = []
        for j in range(len(emb_str[i])):
            temp = float(emb_str[i][j])*100
            tmp.append(temp)
        tmp_X = tmp[:feature_dim]
        tmp_Y = tmp[feature_dim:feature_dim*2]
        emb_X.append(tmp_X)
        emb_Y.append(tmp_Y)

    return emb_X, emb_Y

def main(args, log):
    start_full = time.time()
    log = log

    path = args.dir
    out_folder = args.out

    feature_dim = args.n #dimension of transformed feature vectors
    seed = args.seed

    folders = next(os.walk(path))[1]
    output_folders = []

    emb_X = []
    emb_Y = []

    for i in range(len(folders)):
        output_folders.append(out_folder + '\\' + folders[i])
        os.mkdir(output_folders[i])
        folders[i] = path + '\\' + folders[i] + '\\embeddings.txt'

    for file in folders:
        tmp_X, tmp_Y = read_emb(file, feature_dim=feature_dim)
        emb_X.append(tmp_X)
        emb_Y.append(tmp_Y)

    z = []
    #RDM
    start_only = time.time()
    np.random.seed(seed)
    random_X = list(np.random.uniform(-2.5,2.5,feature_dim))

    np.random.seed(int(seed+10))
    random_Y = list(np.random.uniform(-2.5,2.5,feature_dim))

    for user in range(len(emb_X)):
        print('User: ', user)
        dist = []
        for j in range(len(emb_X[user])):
            tmp_dist = []
            for k in range(len(emb_X[user][j])):
                x = emb_X[user][j][k]
                y = emb_Y[user][j][k]
                user_point = [x, y]
                rand_point = [random_X[j], random_Y[j]]
                rand_dist = np.linalg.norm(np.array(user_point) - np.array(rand_point))
                tmp_dist.append(rand_dist)

            med_fil = list(ndimage.median_filter(tmp_dist, size=3))
            dist.append(med_fil)

        z.append(dist)

    end_only = time.time()
    #Writing transformed data
    for i in range(len(output_folders)):
        _euclidean = open(output_folders[i] + '\embeddings.txt', 'w')
        for row in range(len(z[i])):
            for col in range(len(z[i][row])):
                print('%f ' % z[i][row][col], end='', file=_euclidean)
            print('\n', end='', file=_euclidean)

        _euclidean.close()

    end_full = time.time()
    duration_full = end_full - start_full
    duration_only_alg = end_only - start_only

    _log = open(out_folder + '\\log.txt', 'w')
    print('Syntax: %s' % log, file=_log)
    print('Duration (full: reading files + running alg + writing results): %f' % duration_full, file=_log)
    print('Duration (running alg): %f' % duration_only_alg, file=_log)
    _log.close()

if __name__ == '__main__':
    main(parse_arguments(sys.argv[1:]), str(sys.argv[1:]))
