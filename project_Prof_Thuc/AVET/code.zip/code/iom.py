import argparse
import numpy as np
import os
from scipy import linalg, sparse
import numbers
import sys
import time
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

def parse_arguments(argv):
    parser = argparse.ArgumentParser()

    parser.add_argument('--dir', type=str)
    parser.add_argument('--out', type=str)
    parser.add_argument('--state', type=int)

    return parser.parse_args(argv)

###################################################################################################################
#Heavily rely on the code of sklearn

def safe_sparse_dot(a, b, dense_output=False):
    if a.ndim > 2 or b.ndim > 2:
        if sparse.issparse(a):
            b_ = np.rollaxis(b, -2)
            b_2d = b_.reshape((b.shape[-2], -1))
            ret = a @ b_2d
            ret = ret.reshape(a.shape[0], *b_.shape[1:])
        elif sparse.issparse(b):
            a_2d = a.reshape(-1, a.shape[-1])
            ret = a_2d @ b
            ret = ret.reshape(*a.shape[:-1], b.shape[1])
        else:
            ret = np.dot(a, b)
    else:
        ret = a @ b

    if (sparse.issparse(a) and sparse.issparse(b)
            and dense_output and hasattr(ret, "toarray")):
        return ret.toarray()
    return ret

def check_random_state(seed):
    if seed is None or seed is np.random:
        return np.random.mtrand._rand
    if isinstance(seed, numbers.Integral):
        return np.random.RandomState(seed)
    if isinstance(seed, np.random.RandomState):
        return seed
    raise ValueError('%r cannot be used to seed a numpy.random.RandomState'
                     ' instance' % seed)

class secure_matrix():
    def __init__(self, m_features=512, n_components=512, random_state=None):
        self.m_features = m_features
        self.n_components = n_components
        self.random_state = random_state

    def fit(self, y=None):
        random_state = check_random_state(self.random_state)
        scale = 1/np.sqrt(self.m_features) #sigma^2 = 1/m => sigma = 1/sqrt(m)

        self.random_weights_ = random_state.normal(loc=0, scale=scale, size=(self.n_components, self.m_features))

        return self
###################################################################################################################

def read_code(path):
    f = open(path, 'r')
    lines = f.readlines()
    codes = []
    for i in range(len(lines)):
        tmp = []
        tmp += lines[i].strip().split("\n")
        tmp = str(tmp[0])
        temp = list(tmp)
        codes.append(temp)
    f.close()

    return codes

def read_emb(path):
    f = open(path, 'r')
    lines = f.readlines()
    emb_str = []
    for i in range(len(lines)):
        tmp = []
        tmp += lines[i].strip().split(" ")
        emb_str.append(tmp)
    f.close()

    emb = []
    for i in range(len(emb_str)):
        tmp = []
        for j in range(len(emb_str[i])):
            temp = float(emb_str[i][j])
            tmp.append(temp)

        emb.append(tmp)

    return emb

def main(args, log):
    start_full = time.time()
    log = log

    path = args.dir
    out_folder = args.out
    state = args.state #generate different W matrices

    output_folders = []
    emb = []
    folders = next(os.walk(path))[1]

    #Reading original data and making output directory
    for i in range(len(folders)):
        output_folders.append(out_folder + '\\' + folders[i])
        os.mkdir(output_folders[i])
        folders[i] = path + '\\' + folders[i] + '\embeddings.txt'

    for file in folders:
        tmp = read_emb(file)
        emb.append(tmp)

    feature_dim = len(emb[0][0]) #dimension of original feature vectors
    window = int(feature_dim/2)

    z = []

    start_only = time.time()
    #Index of max: binary i.e., 2 windows
    for i in range(len(emb)):
        print("User: ", i)
        tmp = []
        for j in range(len(emb[i])):
            iom = []
            for index in range(feature_dim):
                project = secure_matrix(m_features=feature_dim, n_components=feature_dim, random_state=int(index*state+index))
                project_weight = project.fit()
                W = project_weight.random_weights_

                project_emb = np.dot(W, emb[i][j])
                index_max = np.argmax(project_emb)

                if (index_max <= window):
                    iom.append(0)
                else:
                    iom.append(1)

            tmp.append(iom)

        z.append(tmp)

    end_only = time.time()
    #Writing transformed data
    for i in range(len(output_folders)):
        _euclidean = open(output_folders[i] + '\embeddings.txt', 'w')
        for row in range(len(z[i])):
            for col in range(len(z[i][row])):
                print('%d ' % int(z[i][row][col]), end='', file=_euclidean)
            print('\n', end='', file=_euclidean)

        _euclidean.close()

    end_full = time.time()
    duration_full = end_full - start_full
    duration_only_alg = end_only - start_only

    _log = open(out_folder + '\\log.txt', 'w')
    print('Syntax: %s' % log, file=_log)
    print('Duration (full: reading files + running alg + writing results): %f' % duration_full, file=_log)
    print('Duration (running alg): %f' % duration_only_alg, file=_log)
    _log.close()

if __name__ == '__main__':
    main(parse_arguments(sys.argv[1:]), str(sys.argv[1:]))
