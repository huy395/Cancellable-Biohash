import os
import sys
import numpy as np
import argparse
from scipy.spatial import distance

def parse_arguments(argv):
    parser = argparse.ArgumentParser()

    parser.add_argument('--dir', type=str)
    #parser.add_argument('--out', type=str)
    parser.add_argument('--gallery', type=int)

    return parser.parse_args(argv)

def read_emb(path):
    f = open(path, 'r')
    lines = f.readlines()
    emb_str = []
    for i in range(len(lines)):
        tmp = []
        tmp += lines[i].strip().split(" ")
        emb_str.append(tmp)
    f.close()

    emb = []
    for i in range(len(emb_str)):
        tmp = []
        for j in range(len(emb_str[i])):
            temp = float(emb_str[i][j])
            tmp.append(temp)

        emb.append(tmp)

    return emb

def main(args):
    path = args.dir
    folder_out = args.dir
    #i-th pic is gallery, remaining pics are probe
    gallery = args.gallery

    folders = next(os.walk(path))[1]
    emb = []

    #read feature vectors
    for i in range(len(folders)):
        folders[i] = path + '\\' + folders[i] + '\\embeddings.txt'

    for file in folders:
        tmp = read_emb(file)
        emb.append(tmp)

    G = []
    P = []
    label = []
    cmc_score = []

    intra = []
    inter = []

    num_of_known_user = len(emb)
    for i in range(len(emb)):
        G.append(emb[i][gallery])
        for j in range(len(emb[i])):
            if(j!=gallery):
                P.append(emb[i][j])
                label.append(i)
    del(emb)

    for i in range(len(P)):
        probe = i
        print('Process: ', i+1, len(P))
        tmp_score = []
        for j in range(len(G)):
            #euc_dist = np.linalg.norm(np.array(P[probe]) - np.array(G[j]))
            euc_dist = distance.cosine(np.array(P[probe]), np.array(G[j])) #cosine distance
            tmp_score.append(euc_dist)
            if(j==label[probe]):#intra
                intra.append(euc_dist)
            else:
                inter.append(euc_dist)

        score_index = np.argsort(tmp_score)
        score_index = list(score_index)
        cmc_score.append(score_index.index(label[i])) #first occurance = rank

    iden_rate = [0]*num_of_known_user
    for rank in range(len(iden_rate)): #max value of identification rate = 1
        count = 0
        for i in range(len(cmc_score)):
            if(cmc_score[i]<rank + 1):
                count += 1
        rate = float(count/len(cmc_score))
        iden_rate[rank] = rate

    #write CMC
    _cmc = open(folder_out + '\cmc_score_' + str(gallery) +'.txt', 'w')
    for i in range(len(iden_rate)):
        print('%f ' % iden_rate[i], end='', file=_cmc)

    _cmc.close()

    #write ROC
    _intra = open(folder_out + '\\intra.txt', 'w')
    _inter = open(folder_out + '\\inter.txt', 'w')

    count = 0
    for i in range(len(intra)):
        print('%f' % intra[i], file=_intra)
        count = count + 1

    print(count)

    count = 0
    for i in range(len(inter)):
        print('%f' % inter[i], file=_inter)
        count = count + 1

    print(count)

    _intra.close()
    _inter.close()

if __name__ == '__main__':
    main(parse_arguments(sys.argv[1:]))
