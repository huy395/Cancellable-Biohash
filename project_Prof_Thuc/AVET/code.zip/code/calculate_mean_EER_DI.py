from sklearn.metrics import roc_curve
from sklearn.metrics import auc
from scipy.optimize import brentq
from scipy.interpolate import interp1d
import numpy as np
import argparse
import sys

def parse_arguments(argv):
    parser = argparse.ArgumentParser()

    parser.add_argument('--dir', type=str)

    return parser.parse_args(argv)

def eer(intra, inter):
    true = []
    predict = []
    for i in range(len(intra)):
        true.append(0)
        predict.append(intra[i])

    for i in range(len(inter)):
        true.append(1)
        predict.append(inter[i])

    fpr, tpr, _ = roc_curve(true, predict)
    area = auc(fpr, tpr)
    #eer = brentq(lambda x : 1. - x - interp1d(fpr, tpr)(x), 0., 1.)
    eer = fpr[np.nanargmin(np.absolute((1 - tpr) - fpr))]

    return eer, area, fpr, tpr

def read_emb(path):
    f = open(path, 'r')
    lines = f.readlines()
    emb_str = []
    for i in range(len(lines)):
        tmp = []
        tmp += lines[i].strip().split(" ")
        emb_str.append(tmp)
    f.close()

    emb = []
    for i in range(len(emb_str)):
        tmp = []
        for j in range(len(emb_str[i])):
            temp = float(emb_str[i][j])
            tmp.append(temp)

        emb.append(tmp)

    return emb

def interpolate(ref, input):
    interp_input = interp1d(np.arange(len(input)), input)
    new_input = interp_input(np.linspace(0, len(input)-1, len(ref)))

    return new_input

def di(intra, inter):
    mean_g = np.mean(intra)
    var_g = np.var(intra)

    mean_i = np.mean(inter)
    var_i = np.var(inter)

    di = np.abs(mean_g-mean_i)/np.sqrt((var_g+var_i)/2)

    return di

def main(args, log):
    dir = args.dir

    path_0 = dir + '\\0'
    path_1 = dir + '\\1'
    path_2 = dir + '\\2'
    path_3 = dir + '\\3'
    path_4 = dir + '\\4'

    intra_0 = read_emb(path_0+'\intra.txt')
    intra_1 = read_emb(path_1+'\intra.txt')
    intra_2 = read_emb(path_2+'\intra.txt')
    intra_3 = read_emb(path_3+'\intra.txt')
    intra_4 = read_emb(path_4+'\intra.txt')

    inter_0 = read_emb(path_0+'\inter.txt')
    inter_1 = read_emb(path_1+'\inter.txt')
    inter_2 = read_emb(path_2+'\inter.txt')
    inter_3 = read_emb(path_3+'\inter.txt')
    inter_4 = read_emb(path_4+'\inter.txt')

    eer_0, area_0, fpr_0, tpr_0 = eer(intra_0, inter_0)
    eer_1, area_1, fpr_1, tpr_1 = eer(intra_1, inter_1)
    eer_2, area_2, fpr_2, tpr_2 = eer(intra_2, inter_2)
    eer_3, area_3, fpr_3, tpr_3 = eer(intra_3, inter_3)
    eer_4, area_4, fpr_4, tpr_4 = eer(intra_4, inter_4)


    new_fpr_1 = interpolate(fpr_0, fpr_1)
    new_fpr_2 = interpolate(fpr_0, fpr_2)
    new_fpr_3 = interpolate(fpr_0, fpr_3)
    new_fpr_4 = interpolate(fpr_0, fpr_4)

    new_tpr_1 = interpolate(tpr_0, tpr_1)
    new_tpr_2 = interpolate(tpr_0, tpr_2)
    new_tpr_3 = interpolate(tpr_0, tpr_3)
    new_tpr_4 = interpolate(tpr_0, tpr_4)

    mean_x = np.mean((new_fpr_1,new_fpr_2,new_fpr_3,new_fpr_4), axis=0)
    mean_y = np.mean((new_tpr_1,new_tpr_2,new_tpr_3,new_tpr_4), axis=0)

    mean_eer = np.mean((eer_0, eer_1, eer_2, eer_3, eer_4))*100
    std_eer = np.std((eer_0, eer_1, eer_2, eer_3, eer_4))*100

    mean_auc = np.mean((area_0, area_1, area_2, area_3, area_4))

    di_0 = di(intra_0, inter_0)
    di_1 = di(intra_1, inter_1)
    di_2 = di(intra_2, inter_2)
    di_3 = di(intra_3, inter_3)
    di_4 = di(intra_4, inter_4)

    mean_di = np.mean((di_0,di_1,di_2,di_3,di_4), axis=0)
    std_di = np.std((di_0,di_1,di_2,di_3,di_4))


    _euclidean = open(dir + '\mean_fpr.txt', 'w')
    for col in range(len(mean_x)):
        print('%f ' % mean_x[col], end='', file=_euclidean)
    print('\n', end='', file=_euclidean)

    _euclidean.close()

    _euclidean = open(dir + '\mean_tpr.txt', 'w')
    for col in range(len(mean_y)):
        print('%f ' % mean_y[col], end='', file=_euclidean)
    print('\n', end='', file=_euclidean)

    _euclidean.close()

    _log = open(dir + '\\result_EER_DI_AUC.txt', 'w')
    print('mean_EER: %f %f' % (mean_eer, std_eer), file=_log)
    print('mean_DI: %f %f' % (float(mean_di), float(std_di)), file=_log)
    print('mean_AUC: %f' % mean_auc, file=_log)
    _log.close()

if __name__ == '__main__':
    main(parse_arguments(sys.argv[1:]), str(sys.argv[1:]))
