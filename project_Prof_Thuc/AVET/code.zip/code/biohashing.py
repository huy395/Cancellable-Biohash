from scipy.stats import ortho_group
import argparse
import numpy as np
import os
from scipy import linalg, sparse
import numbers
import sys
import time
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

def parse_arguments(argv):
    parser = argparse.ArgumentParser()

    parser.add_argument('--dir', type=str)
    parser.add_argument('--out', type=str)
    parser.add_argument('--state', type=int)

    return parser.parse_args(argv)

def read_emb(path):
    f = open(path, 'r')
    lines = f.readlines()
    emb_str = []
    for i in range(len(lines)):
        tmp = []
        tmp += lines[i].strip().split(" ")
        emb_str.append(tmp)
    f.close()

    emb = []
    for i in range(len(emb_str)):
        tmp = []
        for j in range(len(emb_str[i])):
            temp = float(emb_str[i][j])
            tmp.append(temp)

        emb.append(tmp)

    return emb

def sign_func(embbeding):
    emb = []
    for i in range(len(embbeding)):
        if (embbeding[i] < 0.0):
            emb.append(0)
        else:
            emb.append(1)
    return emb

def main(args, log):
    start_full = time.time()
    log = log

    path = args.dir
    out_folder = args.out

    state = args.state

    output_folders = []
    emb = []
    folders = next(os.walk(path))[1]

    #Reading original data and making output directory
    for i in range(len(folders)):
        output_folders.append(out_folder + '\\' + folders[i])
        os.mkdir(output_folders[i])
        folders[i] = path + '\\' + folders[i] + '\embeddings.txt'

    for file in folders:
        tmp = read_emb(file)
        emb.append(tmp)

    #Sampling orthogonal matrix R
    start_only = time.time()
    np.random.seed(state)
    feature_dim = len(emb[0][0])
    R_user = ortho_group.rvs(dim=feature_dim)

    z = []

    #Biohashing
    for i in range(len(emb)):
        print(i)
        tmp = []
        for j in range(len(emb[i])):

            projected = np.dot(R_user, emb[i][j])

            transformed = sign_func(projected)

            tmp.append(transformed)

        z.append(tmp)

    end_only = time.time()
    #Writing transformed data
    for i in range(len(output_folders)):
        _euclidean = open(output_folders[i] + '\embeddings.txt', 'w')
        for row in range(len(z[i])):
            for col in range(len(z[i][row])):
                print('%d ' % int(z[i][row][col]), end='', file=_euclidean)
            print('\n', end='', file=_euclidean)

        _euclidean.close()

    end_full = time.time()
    duration_full = end_full - start_full
    duration_only_alg = end_only - start_only

    _log = open(out_folder + '\\log.txt', 'w')
    print('Syntax: %s' % log, file=_log)
    print('Duration (full: reading files + running alg + writing results): %f' % duration_full, file=_log)
    print('Duration (running alg): %f' % duration_only_alg, file=_log)
    _log.close()

if __name__ == '__main__':
    main(parse_arguments(sys.argv[1:]), str(sys.argv[1:]))


#Check orthogonal matrix or not
#for i in range(len(m)):
#    print(np.linalg.norm(m[i], ord=2))



