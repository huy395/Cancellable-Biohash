Step 1. rdm.py => protected template (5 folders x 3 window size = 15 folders each dataset)
Step 2. rdm_CMC_ROC_cosine.py
Step 3. calculate_CMC_ROC.py
Step 4. calculate_mean_EER_DI.py

report: EER, RI, DI metrics